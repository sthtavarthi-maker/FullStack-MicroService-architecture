package com.campus.event_management.dto;

import java.time.LocalDateTime;

public class RegistrationDTO {

    private Long id;
    private String studentName;
    private String eventTitle;
    private LocalDateTime registeredAt;

    // Constructor
    public RegistrationDTO(Long id, String studentName, String eventTitle, LocalDateTime registeredAt) {
        this.id = id;
        this.studentName = studentName;
        this.eventTitle = eventTitle;
        this.registeredAt = registeredAt;
    }

    // Getters
    public Long getId() { return id; }
    public String getStudentName() { return studentName; }
    public String getEventTitle() { return eventTitle; }
    public LocalDateTime getRegisteredAt() { return registeredAt; }
}