package com.campus.event_management.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.campus.event_management.entity.Student;

public interface StudentRepository extends JpaRepository<Student, Long> {
}