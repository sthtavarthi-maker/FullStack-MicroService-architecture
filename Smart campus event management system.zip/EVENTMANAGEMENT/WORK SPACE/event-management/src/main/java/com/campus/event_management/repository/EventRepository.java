package com.campus.event_management.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.campus.event_management.entity.Event;

public interface EventRepository extends JpaRepository<Event, Long> {
}