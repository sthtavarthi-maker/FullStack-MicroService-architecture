package com.campus.event_management.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.campus.event_management.entity.Event;
import com.campus.event_management.entity.Student;
import com.campus.event_management.service.EventService;
import com.campus.event_management.service.StudentService;

import java.util.List;

@RestController
public class TestController {

    // ✅ Inject Services
    @Autowired
    private EventService eventService;

    @Autowired
    private StudentService studentService;

    // ===================== STUDENT APIs =====================

    // ✅ Add Student (POST - from Postman)
    @PostMapping("/student")
    public Student addStudent(@RequestBody Student s) {
        return studentService.saveStudent(s);
    }

    // ✅ Add Student (GET - test)
    @GetMapping("/add-student")
    public String addStudentTest() {
        Student s = new Student();
        s.setName("Keeru");
        s.setEmail("keeru@gmail.com");
        s.setDepartment("CSE");

        studentService.saveStudent(s);

        return "Student Added!";
    }

    // ===================== EVENT APIs =====================

    // ✅ Add Event
    @PostMapping("/add")
    public Event addEvent(@RequestBody Event event) {
        return eventService.saveEvent(event);
    }

    // ✅ Get All Events
    @GetMapping("/events")
    public List<Event> getAllEvents() {
        return eventService.getAllEvents();
    }

    // ✅ Get Event by ID
    @GetMapping("/events/{id}")
    public Event getEventById(@PathVariable Long id) {
        return eventService.getEventById(id);
    }

    // ✅ Add Test Event
    @GetMapping("/add-test")
    public String addTestEvent() {
        Event e = new Event();
        e.setTitle("Demo Event");
        e.setDescription("Test Event");
        e.setDepartment("CSE");
        e.setType("Technical");
        e.setCapacity(50);

        eventService.saveEvent(e);

        return "Event Added!";
    }
}