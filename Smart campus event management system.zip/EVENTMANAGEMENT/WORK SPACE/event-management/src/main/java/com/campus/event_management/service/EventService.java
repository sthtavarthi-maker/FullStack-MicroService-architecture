package com.campus.event_management.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.campus.event_management.entity.Event;
import com.campus.event_management.exception.ResourceNotFoundException;
import com.campus.event_management.repository.EventRepository;

import java.util.List;
@Service
public class EventService {

    @Autowired
    private EventRepository eventRepo;

    // Save event
    public Event saveEvent(Event event) {
        return eventRepo.save(event);
    }

    // Get all events
    public List<Event> getAllEvents() {
        return eventRepo.findAll();
    }
    public Event getEventById(Long id) {
        return eventRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Event not found"));
    }
}