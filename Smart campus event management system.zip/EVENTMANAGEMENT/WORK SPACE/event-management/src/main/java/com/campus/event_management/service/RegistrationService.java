package com.campus.event_management.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.campus.event_management.entity.Event;
import com.campus.event_management.entity.Student;
import com.campus.event_management.exception.ResourceNotFoundException;
import com.campus.event_management.entity.Registration;
import com.campus.event_management.repository.EventRepository;
import com.campus.event_management.repository.StudentRepository;
import com.campus.event_management.repository.RegistrationRepository;

import java.util.List;
import com.campus.event_management.dto.RegistrationDTO;
import java.util.stream.Collectors;

@Service
public class RegistrationService {

    @Autowired
    private RegistrationRepository regRepo;

    @Autowired
    private StudentRepository studentRepo;

    @Autowired
    private EventRepository eventRepo;

    // ✅ Register student to event
    public Registration register(Long studentId, Long eventId) {

        // 1. Check student exists
        Student student = studentRepo.findById(studentId).orElse(null);
        if (student == null) {
            throw new ResourceNotFoundException("Student not found!");
        }

        // 2. Check event exists
        Event event = eventRepo.findById(eventId).orElse(null);
        if (event == null) {
            throw new ResourceNotFoundException("Event not found!");
        }

        // 3. Prevent duplicate
        boolean alreadyExists = regRepo.existsByStudentIdAndEventId(studentId, eventId);
        if (alreadyExists) {
            throw new RuntimeException("Student already registered!");
        }

        // 4. Check capacity
        long count = regRepo.countByEventId(eventId);
        if (count >= event.getCapacity()) {
            throw new RuntimeException("Event is full!");
        }

        // 5. Save registration
        Registration reg = new Registration();
        reg.setStudent(student);
        reg.setEvent(event);

        return regRepo.save(reg);
    }

    // ✅ Get all registrations
    public List<RegistrationDTO> getAllRegistrations() {

        return regRepo.findAll()
                .stream()
                .map(r -> new RegistrationDTO(
                        r.getId(),
                        r.getStudent().getName(),
                        r.getEvent().getTitle(),
                        r.getRegisteredAt()
                ))
                .collect(Collectors.toList());
    }

    // ✅ Get by student
    public List<RegistrationDTO> getByStudent(Long studentId) {
        return regRepo.findByStudentId(studentId)
                .stream()
                .map(r -> new RegistrationDTO(
                        r.getId(),
                        r.getStudent().getName(),
                        r.getEvent().getTitle(),
                        r.getRegisteredAt()
                ))
                .collect(Collectors.toList());
    }

    // ✅ Get by event
    public List<RegistrationDTO> getByEvent(Long eventId) {
        return regRepo.findByEventId(eventId)
                .stream()
                .map(r -> new RegistrationDTO(
                        r.getId(),
                        r.getStudent().getName(),
                        r.getEvent().getTitle(),
                        r.getRegisteredAt()
                ))
                .collect(Collectors.toList());
    }
}