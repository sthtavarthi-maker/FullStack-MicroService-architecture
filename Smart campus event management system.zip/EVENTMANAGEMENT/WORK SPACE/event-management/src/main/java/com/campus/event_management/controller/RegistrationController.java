package com.campus.event_management.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.campus.event_management.entity.Registration;
import com.campus.event_management.service.RegistrationService;
import com.campus.event_management.dto.RegistrationDTO;

import java.util.List;

@RestController
public class RegistrationController {

    @Autowired
    private RegistrationService registrationService;

    // ✅ Register student
    @PostMapping("/register")
    public Registration register(
            @RequestParam Long studentId,
            @RequestParam Long eventId) {

        return registrationService.register(studentId, eventId);
    }

    // ✅ Get all registrations
    @GetMapping("/registrations")
    public List<RegistrationDTO> getAll() {
        return registrationService.getAllRegistrations();
    }

    // ✅ Get registrations by student
    @GetMapping("/registrations/student/{id}")
    public List<RegistrationDTO> getByStudent(@PathVariable Long id) {
        return registrationService.getByStudent(id);
    }

    // ✅ Get registrations by event
    @GetMapping("/registrations/event/{id}")
    public List<RegistrationDTO> getByEvent(@PathVariable Long id) {
        return registrationService.getByEvent(id);
    }
}