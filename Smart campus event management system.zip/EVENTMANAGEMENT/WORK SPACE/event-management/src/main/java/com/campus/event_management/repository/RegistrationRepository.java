package com.campus.event_management.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import com.campus.event_management.entity.Registration;

public interface RegistrationRepository extends JpaRepository<Registration, Long> {
	
	boolean existsByStudentIdAndEventId(Long studentId, Long eventId);

    long countByEventId(Long eventId);
    
    List<Registration> findByStudentId(Long studentId);

    List<Registration> findByEventId(Long eventId);
}