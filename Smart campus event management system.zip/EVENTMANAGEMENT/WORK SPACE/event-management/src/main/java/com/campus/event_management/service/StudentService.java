package com.campus.event_management.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.campus.event_management.entity.Student;
import com.campus.event_management.repository.StudentRepository;

import java.util.List;

@Service
public class StudentService {

    @Autowired
    private StudentRepository studentRepo;

    // ✅ Save Student
    public Student saveStudent(Student s) {
        return studentRepo.save(s);
    }

    // ✅ Get All Students
    public List<Student> getAllStudents() {
        return studentRepo.findAll();
    }

    // ✅ Get Student By ID
    public Student getStudentById(Long id) {
        return studentRepo.findById(id).orElse(null);
    }

    // ✅ Delete Student
    public String deleteStudent(Long id) {
        studentRepo.deleteById(id);
        return "Student Deleted Successfully";
    }

    // ✅ Update Student
    public Student updateStudent(Long id, Student newStudent) {
        Student existing = studentRepo.findById(id).orElse(null);

        if (existing != null) {
            existing.setName(newStudent.getName());
            existing.setEmail(newStudent.getEmail());
            return studentRepo.save(existing);
        }

        return null;
    }
}